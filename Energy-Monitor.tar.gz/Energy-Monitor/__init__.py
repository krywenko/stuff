
#from adapt.intent import IntentBuilder
from mycroft import MycroftSkill, intent_handler

class EnergyMonitorSkill(MycroftSkill):
    def __init__(self):
        MycroftSkill.__init__(self)

    def initialize(self):
        my_setting = self.settings.get('my_setting')

    @intent_handler('energy.monitor.intent')
    def handle_energy_monitor(self, message):
        self.speak(' energy  display ')
        self.gui.show_url("http://localhost:3000/d/B72_dufMz/energymonitor?viewPanel=2&orgId=1&refresh=10s", override_idle=600000)
        
    @intent_handler('temperature.monitor.intent')
    def handle_temperature_monitor(self, message):
        self.speak(' temperature  display ')
        self.gui.show_url("http://localhost:3000/d/7oa9fufGk/temperature?viewPanel=2&orgId=1&refresh=10s&from=now-24h&to=now", override_idle=600000)  
  
  
    def stop(self):
        pass


def create_skill():
    return EnergyMonitorSkill()
